WULIX — Pack Scripts Python 29EUR
================================

5 scripts Python prets a emploi :
1_scraper_donnees.py        - Scraper web > CSV
2_relance_email.py          - Relance email automatique
3_generateur_rapport_pdf.py - Rapport PDF depuis CSV
4_autoposter_linkedin.py    - Auto-poster LinkedIn API
5_veille_concurrentielle.py - Veille Google News > HTML

Prerequis : pip install requests beautifulsoup4 fpdf2
Support   : contact@wulix.fr | wulix.fr
Licence   : Usage personnel uniquement. Non redistribuable.
(c) 2026 WULIX — Art. L.335-2 CPI
